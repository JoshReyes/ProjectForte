package com.example.pc2.finalproject;

import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

/**
 * Created by PC2 on 4/25/2016.
 */
public class DrawerItemClickListener implements android.widget.AdapterView.OnItemClickListener
{
    public void onItemClick(AdapterView parent, View view, int position, long id )
    {
        //selectItem( position );
    }

    public void selectItem( long position )
    {
        //Toast.makeText( context,  );
    }
}
