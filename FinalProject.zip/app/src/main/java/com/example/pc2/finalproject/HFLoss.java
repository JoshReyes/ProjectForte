package com.example.pc2.finalproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class HFLoss extends BaseScreen
{
    @Override
    protected void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_hfloss );
    }
}
